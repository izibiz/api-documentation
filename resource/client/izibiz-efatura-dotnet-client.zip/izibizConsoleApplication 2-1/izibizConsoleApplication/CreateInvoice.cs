﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Serialization;
using System.Xml.XPath;
using System.Xml.Xsl;
using UBLInvoice_2_1;

namespace izibizConsoleApplication
{
    class CreateInvoice
    {
        public string createInvoice()
        {
            InvoiceType invoice = new InvoiceType();


            UBLVersionIDType ublVersionId = new UBLVersionIDType();
            ublVersionId.Value = "2.1";
            invoice.UBLVersionID = ublVersionId;

            CustomizationIDType CustomizationIDType = new CustomizationIDType();
            CustomizationIDType.Value = "TR1.2";
            invoice.CustomizationID = CustomizationIDType;

            ProfileIDType ProfileIDType = new ProfileIDType();
            ProfileIDType.Value = "TEMELFATURA";
            invoice.ProfileID = ProfileIDType;

            IDType id = new IDType();
            id.Value = "YSR2015000012104";
            invoice.ID = id;

            CopyIndicatorType CopyIndicatorType = new CopyIndicatorType();
            CopyIndicatorType.Value = false;
            invoice.CopyIndicator = CopyIndicatorType;

            UUIDType UUIDType = new UUIDType();
            UUIDType.Value = System.Guid.NewGuid().ToString();
            invoice.UUID = UUIDType;

            IssueDateType issuedate = new IssueDateType();
            issuedate.Value = DateTime.Now;
            invoice.IssueDate = issuedate;

            IssueTimeType issuetime = new IssueTimeType();
            issuetime.Value = DateTime.Now;
            invoice.IssueTime = issuetime;

            InvoiceTypeCodeType InvoiceTypeCodeType = new InvoiceTypeCodeType();
            InvoiceTypeCodeType.Value = "SATIS";
            invoice.InvoiceTypeCode = InvoiceTypeCodeType;

            NoteType[] note = new NoteType[] { new NoteType { Value = "sdfasdfas" }, new NoteType { Value = "aaaaa" } };

            invoice.Note = note;

            invoice.DocumentCurrencyCode = new DocumentCurrencyCodeType { Value = "TRY" };
            invoice.LineCountNumeric = new LineCountNumericType { Value = 1m };

            DocumentReferenceType[] documentRefArr = new DocumentReferenceType[1];
            DocumentReferenceType documentRef = new DocumentReferenceType();
            AttachmentType attachment = new AttachmentType();
            EmbeddedDocumentBinaryObjectType embedebOcject = new EmbeddedDocumentBinaryObjectType();
            string xsltFile = @"C:\Users\yasar.gunes\Desktop\0_tmp.xslt";
            System.IO.FileStream fileXml = new System.IO.FileStream(xsltFile, FileMode.Open, FileAccess.Read);
            System.IO.StreamReader sr = new System.IO.StreamReader(fileXml, Encoding.UTF8);
            string xsltString = sr.ReadToEnd();
            byte[] contentByte = Encoding.UTF8.GetBytes(xsltString);
            embedebOcject.characterSetCode = "UTF-8";
            embedebOcject.encodingCode = "Base64";
            embedebOcject.filename = "faturano.xslt";
            embedebOcject.mimeCode = "application/xml";
            embedebOcject.Value = contentByte;
            attachment.EmbeddedDocumentBinaryObject = embedebOcject;
            documentRef.Attachment = attachment;

            IDType documentRefId = new IDType();
            documentRefId.Value = System.Guid.NewGuid().ToString();
            documentRef.ID = documentRefId;

            IssueDateType documentRefIssueDate = new IssueDateType();
            documentRefIssueDate.Value = DateTime.Now;
            documentRef.IssueDate = documentRefIssueDate;

            DocumentTypeType documentRefDocumentType = new DocumentTypeType();
            documentRefDocumentType.Value = "XSLT";
            documentRef.DocumentType = documentRefDocumentType;
            documentRefArr[0] = documentRef;
            invoice.AdditionalDocumentReference = documentRefArr;

            SignatureType[] signArr = new SignatureType[] { new SignatureType() };
            AttachmentType signAttch = new AttachmentType();

            signAttch.ExternalReference = new ExternalReferenceType() { URI = new URIType { Value = "#Signature_DMY20150922204254" } };

            PartyIdentificationType[] signPartyid = new PartyIdentificationType[] { new PartyIdentificationType { ID = new IDType { schemeID = "VKN", Value = "4840847211" } } };


            AddressType signPartyAddr = new AddressType();
            signPartyAddr.StreetName = new StreetNameType() { Value = "DAVUT PAŞA" };
            signPartyAddr.BuildingName = new BuildingNameType() { Value = "C1" };
            signPartyAddr.BuildingNumber = new BuildingNumberType() { Value = "301" };
            signPartyAddr.CitySubdivisionName = new CitySubdivisionNameType() { Value = "MAHALL" };
            signPartyAddr.CityName = new CityNameType() { Value = "İSTANBUL" };
            signPartyAddr.PostalZone = new PostalZoneType() { Value = "34100" };
            signPartyAddr.Region = new RegionType() { Value = "İSTANBUL" };
            signPartyAddr.Country = new CountryType() { Name = new NameType1() { Value = "TR" } };


            PartyType signParty = new PartyType();
            signParty.PartyIdentification = signPartyid;
            signParty.PostalAddress = signPartyAddr;

            signArr[0].ID = new IDType { schemeID = "VKN_TCKN", Value = "4840847211" };
            signArr[0].SignatoryParty = signParty;
            signArr[0].DigitalSignatureAttachment = signAttch;


            invoice.Signature = signArr;


            SupplierPartyType supplier = new SupplierPartyType();
            PartyType suppParty = new PartyType();
            suppParty.WebsiteURI = new WebsiteURIType() { Value = "www.izibiz.com.tr" };

            PartyIdentificationType[] suppPartyid = new PartyIdentificationType[]{
                new PartyIdentificationType{ ID = new IDType{ schemeID = "VKN", Value = "4840847211" }},
                new PartyIdentificationType{ ID = new IDType { schemeID = "MERSISNO", Value = "110220444" }}
            };

            suppParty.PartyIdentification = suppPartyid;
            suppParty.PartyName = new PartyNameType { Name = new NameType1 { Value = "İZİBİZ BİLİŞİM TEKNOLOJİLERİ" } };

            AddressType suppPartyAddr = new AddressType();
            suppPartyAddr.StreetName = new StreetNameType() { Value = "Bahalibahce Sok." };
            suppPartyAddr.BuildingName = new BuildingNameType() { Value = "Cenk Ap." };
            suppPartyAddr.BuildingNumber = new BuildingNumberType() { Value = "11/2" };
            suppPartyAddr.CitySubdivisionName = new CitySubdivisionNameType() { Value = "Bakirkoy" };
            suppPartyAddr.CityName = new CityNameType() { Value = "İSTANBUL" };
            suppPartyAddr.PostalZone = new PostalZoneType() { Value = "34100" };
            suppPartyAddr.Region = new RegionType() { Value = "INCIRLI" };
            suppPartyAddr.Country = new CountryType() { Name = new NameType1() { Value = "TR" } };

            suppParty.PostalAddress = suppPartyAddr;
            suppParty.PartyTaxScheme = new PartyTaxSchemeType { TaxScheme = new TaxSchemeType { Name = new NameType1 { Value = "BAKIRKOY" } } };
            suppParty.Contact = new ContactType { ElectronicMail = new ElectronicMailType { Value = "yasar.gunes@izibiz.com.tr" } };

            supplier.Party = suppParty;

            invoice.AccountingSupplierParty = supplier;


            CustomerPartyType customer = new CustomerPartyType();
            PartyType customerParty = new PartyType();

            PartyIdentificationType[] customerPartyid = new PartyIdentificationType[]{
                new PartyIdentificationType{ ID = new IDType{ schemeID = "VKN", Value = "1122334455" }}
            };
            customerParty.PartyIdentification = customerPartyid;
            customerParty.PartyName = new PartyNameType { Name = new NameType1 { Value = "Deneme Ltd. Sti." } };

            AddressType customerPartyAddr = new AddressType();
            customerPartyAddr.StreetName = new StreetNameType() { Value = "Akasya Sok." };
            customerPartyAddr.BuildingName = new BuildingNameType() { Value = "Ahmet Ap." };
            customerPartyAddr.BuildingNumber = new BuildingNumberType() { Value = "5" };
            customerPartyAddr.CitySubdivisionName = new CitySubdivisionNameType() { Value = "Bahcelievler" };
            customerPartyAddr.CityName = new CityNameType() { Value = "İSTANBUL" };
            customerPartyAddr.PostalZone = new PostalZoneType() { Value = "34100" };
            customerPartyAddr.Region = new RegionType() { Value = "Yayla" };
            customerPartyAddr.Country = new CountryType() { Name = new NameType1() { Value = "TR" } };

            customerParty.PostalAddress = customerPartyAddr;
            customerParty.PartyTaxScheme = new PartyTaxSchemeType { TaxScheme = new TaxSchemeType { Name = new NameType1 { Value = "BAKIRKOY" } } };

            customer.Party = customerParty;

            invoice.AccountingCustomerParty = customer;


            AllowanceChargeType[] iskonto = new AllowanceChargeType[]{
                new AllowanceChargeType{ ChargeIndicator= new ChargeIndicatorType {Value = false},
                                         Amount= new AmountType2 { currencyID = "TRY", Value = 0m }
                }
            };

            invoice.AllowanceCharge = iskonto;

            TaxTotalType[] vergiToplam = new TaxTotalType[1];

            vergiToplam[0] = new TaxTotalType();
            vergiToplam[0].TaxAmount = new TaxAmountType { currencyID = "TRY", Value = 1.8m };

            TaxSubtotalType[] vergiaraToplam = new TaxSubtotalType[1];
            vergiaraToplam[0] = new TaxSubtotalType();
            vergiaraToplam[0].TaxableAmount = new TaxableAmountType { currencyID = "TRY", Value = 10m };
            vergiaraToplam[0].TaxAmount = new TaxAmountType { currencyID = "TRY", Value = 1.8m };
            vergiaraToplam[0].CalculationSequenceNumeric = new CalculationSequenceNumericType { Value = 1m };
            vergiaraToplam[0].Percent = new PercentType1 { Value = 18m };

            TaxCategoryType vergikategori = new TaxCategoryType { TaxScheme = new TaxSchemeType { Name = new NameType1 { Value = "KDV" }, TaxTypeCode = new TaxTypeCodeType { Value = "0015" } } };
            vergiaraToplam[0].TaxCategory = vergikategori;

            vergiToplam[0].TaxSubtotal = vergiaraToplam;

            invoice.TaxTotal = vergiToplam;

            invoice.LegalMonetaryTotal = new MonetaryTotalType
            {
                LineExtensionAmount = new LineExtensionAmountType { currencyID = "TRY", Value = 10m },
                TaxExclusiveAmount = new TaxExclusiveAmountType { currencyID = "TRY", Value = 10m },
                TaxInclusiveAmount = new TaxInclusiveAmountType { currencyID = "TRY", Value = 11.8m },
                AllowanceTotalAmount = new AllowanceTotalAmountType { currencyID = "TRY", Value = 0m },
                PayableAmount = new PayableAmountType { currencyID = "TRY", Value = 11.8m }
            };

            InvoiceLineType[] fatKalemler = new InvoiceLineType[1];
            InvoiceLineType fatkalem = new InvoiceLineType();

            fatkalem.ID = new IDType { Value = "1" };
            fatkalem.InvoicedQuantity = new InvoicedQuantityType { unitCode = "C62", Value = 1m };
            fatkalem.LineExtensionAmount = new LineExtensionAmountType { currencyID = "TRY", Value = 10m };

            AllowanceChargeType[] kalemIskonto = new AllowanceChargeType[1];
            kalemIskonto[0] = new AllowanceChargeType();
            kalemIskonto[0].ChargeIndicator = new ChargeIndicatorType { Value = false };
            kalemIskonto[0].MultiplierFactorNumeric = new MultiplierFactorNumericType { Value = 0m };
            kalemIskonto[0].Amount = new AmountType2 { currencyID = "TRY", Value = 0m };
            kalemIskonto[0].BaseAmount = new BaseAmountType { currencyID = "TRY", Value = 0m };

            fatkalem.AllowanceCharge = kalemIskonto;


            TaxTotalType kalemvergiToplam = new TaxTotalType();

            kalemvergiToplam.TaxAmount = new TaxAmountType { currencyID = "TRY", Value = 1.8m };

            TaxSubtotalType[] kalemvergiaraToplam = new TaxSubtotalType[1];
            kalemvergiaraToplam[0] = new TaxSubtotalType();
            kalemvergiaraToplam[0].TaxableAmount = new TaxableAmountType { currencyID = "TRY", Value = 10m };
            kalemvergiaraToplam[0].TaxAmount = new TaxAmountType { currencyID = "TRY", Value = 1.8m };
            kalemvergiaraToplam[0].CalculationSequenceNumeric = new CalculationSequenceNumericType { Value = 1m };
            kalemvergiaraToplam[0].Percent = new PercentType1 { Value = 18m };

            TaxCategoryType kalemvergikategori = new TaxCategoryType { TaxScheme = new TaxSchemeType { Name = new NameType1 { Value = "KDV" }, TaxTypeCode = new TaxTypeCodeType { Value = "0015" } } };
            kalemvergiaraToplam[0].TaxCategory = kalemvergikategori;

            kalemvergiToplam.TaxSubtotal = kalemvergiaraToplam;

            fatkalem.TaxTotal = kalemvergiToplam;
            fatkalem.Item = new ItemType { Name = new NameType1 { Value = "Tahta" } };
            fatkalem.Price = new PriceType { PriceAmount = new PriceAmountType { currencyID = "TRY", Value = 10m } };

            fatKalemler[0] = fatkalem;

            invoice.InvoiceLine = fatKalemler;

            XmlWriterSettings settings = new XmlWriterSettings();
            settings.OmitXmlDeclaration = true;
            settings.Indent = true;
            //settings.NewLineOnAttributes = true;
            MemoryStream memoryStream = new MemoryStream();
            XmlWriter writer = XmlWriter.Create(memoryStream, settings);
            XmlSerializer x = new XmlSerializer(invoice.GetType());
            x.Serialize(writer, invoice, invoiceNameSpaces());

            memoryStream.Flush();
            memoryStream.Seek(0, SeekOrigin.Begin);
            StreamReader srRead = new StreamReader(memoryStream);

            //x.Serialize(TW, Object);
            string readXml = srRead.ReadToEnd();
            string filePath = Path.Combine("d:/", invoice.ID.Value.ToString() + ".xml");
            using (StreamWriter outFile = new StreamWriter(filePath, false, System.Text.Encoding.UTF8))
            {
                outFile.Write(readXml);
                outFile.Close();
            }

            return filePath;

            //invoice.SaveToFile(@"E:\deneme.xml");



        }

        public static XmlSerializerNamespaces invoiceNameSpaces()
        {
            XmlSerializerNamespaces ns = new XmlSerializerNamespaces();
            ns.Add("cac", "urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2");
            ns.Add("xsi", "http://www.w3.org/2001/XMLSchema-instance");

            ns.Add("xades", "http://uri.etsi.org/01903/v1.3.2#");
            ns.Add("udt", "urn:un:unece:uncefact:data:specification:UnqualifiedDataTypesSchemaModule:2");
            ns.Add("ubltr", "urn:oasis:names:specification:ubl:schema:xsd:TurkishCustomizationExtensionComponents");
            ns.Add("qdt", "urn:oasis:names:specification:ubl:schema:xsd:QualifiedDatatypes-2");
            ns.Add("ext", "urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2");
            ns.Add("cbc", "urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2");
            ns.Add("ccts", "urn:un:unece:uncefact:documentation:2");
            ns.Add("ds", "http://www.w3.org/2000/09/xmldsig#");
            return ns;
        }

        public void viewInvoice()
        {
            String xslt = "C:/Users/yasar/Desktop/gib_default_eFatura-xslt.xslt";
            String input = "C:/Users/yasar/Desktop/faturaxml.xml";
            String output = "C:/Users/yasar/Desktop/TransformOutputXml.xml";

            XPathDocument myXMLPath = new XPathDocument(input);
            XslCompiledTransform myXSLTrans = new XslCompiledTransform();
            myXSLTrans.Load(xslt);
            XmlTextWriter myWriter = new XmlTextWriter(output, null);
            myXSLTrans.Transform(myXMLPath, null, myWriter);
            myWriter.Close();
            System.IO.FileStream fileXml = new System.IO.FileStream(output, FileMode.Open, FileAccess.Read);
            System.IO.StreamReader sr = new System.IO.StreamReader(fileXml, Encoding.UTF8);
            string xmlString = sr.ReadToEnd();
            //webBrowser1.DocumentText = xmlString;
        }

    }
}
