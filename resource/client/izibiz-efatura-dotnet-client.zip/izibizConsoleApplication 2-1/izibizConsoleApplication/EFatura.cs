﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace izibizConsoleApplication {

    class EFatura {
      

        private izibiz.EFaturaOIBPortClient service;
        private auth.AuthenticationServicePortClient authService;
        private izibiz.REQUEST_HEADERType requestHeader;

        private auth.REQUEST_HEADERType authrequestHeader;

        public EFatura() {
            initialize();
        }

        private void initialize() {
            service = new izibiz.EFaturaOIBPortClient();
            authService = new auth.AuthenticationServicePortClient();
            authRequestHead("0");
            oibRequestHead("0");
        }

        public void login(String userName, String password) {
            System.Console.WriteLine("/****** LOGIN() *******/");
            auth.LoginRequest loginRequest = new auth.LoginRequest();
            loginRequest.USER_NAME = userName;
            loginRequest.PASSWORD = password;
            loginRequest.REQUEST_HEADER = authrequestHeader;

            auth.LoginResponse loginResponse = authService.Login(loginRequest);
            String sessionId = loginResponse.SESSION_ID;
            requestHeader.SESSION_ID = sessionId;
            authrequestHeader.SESSION_ID = sessionId;
        }


         public void logout() {
            System.Console.WriteLine("/****** LOGOUT() *******/");
            auth.LogoutRequest logoutRequest = new auth.LogoutRequest();
            logoutRequest.REQUEST_HEADER = authrequestHeader;

            auth.LogoutResponse logoutResponse = authService.Logout(logoutRequest);
        }

        public void getInvoice_ReceivedHeaderOnlyList(string direction,string headerOnly)
        {
            System.Console.WriteLine("/****** GETINVOICELIST_RECEIVED_HEADERONLY() *******/");
            izibiz.GetInvoiceRequest getInvoiceRequest = new izibiz.GetInvoiceRequest();
            izibiz.GetInvoiceRequestINVOICE_SEARCH_KEY invoiceSearchKey = new izibiz.GetInvoiceRequestINVOICE_SEARCH_KEY();
            invoiceSearchKey.LIMIT = 100;
            invoiceSearchKey.LIMITSpecified = true;
            invoiceSearchKey.READ_INCLUDED = true;
            invoiceSearchKey.READ_INCLUDEDSpecified = true;
            invoiceSearchKey.DIRECTION = direction;
            getInvoiceRequest.HEADER_ONLY = headerOnly;
            getInvoiceRequest.INVOICE_SEARCH_KEY = invoiceSearchKey;
            getInvoiceRequest.REQUEST_HEADER = requestHeader;

            izibiz.INVOICE[] invoiceList = service.GetInvoice(getInvoiceRequest);
            foreach (izibiz.INVOICE invoice in invoiceList)
            {
                System.Console.WriteLine(invoice.UUID.ToString() + "\t" + invoice.ID + "\t" +
                    invoice.HEADER.FROM + "\t" + invoice.HEADER.TO + "\t" +
                    invoice.HEADER.SUPPLIER + "\t" + invoice.HEADER.CUSTOMER + "\t" +
                    invoice.HEADER.SENDER + "\t" + invoice.HEADER.RECEIVER);
            }
            System.Console.WriteLine("Total Record Count :" + invoiceList.Length);
        }

        public void getInvoicesSent()
        {
            System.Console.WriteLine("/****** GETINVOICESSENT() *******/");            
            izibiz.GetInvoiceRequest getInvoiceRequest = new izibiz.GetInvoiceRequest();
            izibiz.GetInvoiceRequestINVOICE_SEARCH_KEY invoiceSearchKey = new izibiz.GetInvoiceRequestINVOICE_SEARCH_KEY();
            invoiceSearchKey.LIMIT = 10;
            invoiceSearchKey.LIMITSpecified = true;
            invoiceSearchKey.READ_INCLUDED = true;
            invoiceSearchKey.READ_INCLUDEDSpecified = false;
            invoiceSearchKey.DIRECTION = "OUT";
            getInvoiceRequest.HEADER_ONLY = "N";
            getInvoiceRequest.INVOICE_SEARCH_KEY = invoiceSearchKey;
            getInvoiceRequest.REQUEST_HEADER = requestHeader;

            izibiz.INVOICE[] invoiceList = service.GetInvoice(getInvoiceRequest);
            foreach (izibiz.INVOICE invoice in invoiceList)
            {
                System.Console.WriteLine(invoice.UUID.ToString() + "\t" + invoice.ID + "\t" +
                    invoice.HEADER.SENDER + "\t" + invoice.HEADER.RECEIVER);
                System.Console.WriteLine("-------------------------------------------------------------");
                System.Console.WriteLine(Encoding.UTF8.GetString(invoice.CONTENT.Value));
            }
            System.Console.WriteLine("Total Record Count :" + invoiceList.Length);
        }

        public void getInvoicesReceived()
        {
            System.Console.WriteLine("/****** GETINVOICESRECEIVED() *******/");
            izibiz.GetInvoiceRequest getInvoiceRequest = new izibiz.GetInvoiceRequest();
            izibiz.GetInvoiceRequestINVOICE_SEARCH_KEY invoiceSearchKey = new izibiz.GetInvoiceRequestINVOICE_SEARCH_KEY();
            invoiceSearchKey.LIMIT = 100;
            invoiceSearchKey.LIMITSpecified = true;
            invoiceSearchKey.READ_INCLUDED = false;
            invoiceSearchKey.READ_INCLUDEDSpecified = true;
            invoiceSearchKey.DIRECTION = "IN";
            getInvoiceRequest.HEADER_ONLY = "N";
            getInvoiceRequest.INVOICE_SEARCH_KEY = invoiceSearchKey;
            getInvoiceRequest.REQUEST_HEADER = requestHeader;

            izibiz.INVOICE[] invoiceList = service.GetInvoice(getInvoiceRequest);
            foreach (izibiz.INVOICE invoice in invoiceList)
            {
                //logInvoice(invoice);
                saveInvoice(invoice);
                getInvoicesReceivedType(invoice);
                // Mark Invoice One by One
                markInvoice(invoice);
            }
            //gelen fatura işlem bitene kadar tekrar çekilir
            if(invoiceList.Length == 100)
            {
                getInvoicesReceived();
            }
           
            System.Console.WriteLine("Total Record Count :" + invoiceList.Length);
        }

        public void getInvoicesReceivedType(izibiz.INVOICE invoiceType)
        {
            System.Console.WriteLine("/****** GETINVOICESRECEIVEDTYPE() *******/");
            izibiz.GetInvoiceWithTypeRequest getInvoiceTypeRequest = new izibiz.GetInvoiceWithTypeRequest();
            izibiz.GetInvoiceWithTypeRequestINVOICE_SEARCH_KEY invoiceSearchKey = new izibiz.GetInvoiceWithTypeRequestINVOICE_SEARCH_KEY();
            invoiceSearchKey.READ_INCLUDED = false;
            invoiceSearchKey.READ_INCLUDEDSpecified = true;
            invoiceSearchKey.DIRECTION = "IN";
            invoiceSearchKey.UUID = invoiceType.UUID;
            invoiceSearchKey.TYPE = "HTML";//XML,PDF,HTML
            getInvoiceTypeRequest.INVOICE_SEARCH_KEY = invoiceSearchKey;
            getInvoiceTypeRequest.REQUEST_HEADER = requestHeader;
            izibiz.INVOICE[] invoiceList = null;
            try
            {
                invoiceList  = service.GetInvoiceWithType(getInvoiceTypeRequest);
                foreach (izibiz.INVOICE invoice in invoiceList)
                {
                    saveInvoiceType(invoice);
                }

                System.Console.WriteLine("Total Record Count :" + invoiceList.Length);
            } catch(Exception ex)
            {
                System.Console.WriteLine("Fatura PDF almada hata: "+ ex);
            }
            
           
        }

        public void markInvoiceManual() {
            // REF: GetInvoice methoduna bakarak markinvoice ve getinvoice nasıl kullanıldıgınıda gorebilirsiniz.
            // Bu methodu kullanmadan once portalden daha once okunmamış fatura bilgilerini almanız gerekir.
            System.Console.WriteLine("/****** MARKINVOICEMANUAL() *******/");

            izibiz.INVOICE[] invoiceList = new izibiz.INVOICE[2];

            izibiz.INVOICE inv1 = new izibiz.INVOICE();
            inv1.ID = "YKA2018000334319";
            inv1.UUID = "65CB2B87-5010-2C3B-E053-0B07010A5780";
            invoiceList[0] = inv1;

                        //faturaları okundu olarak işaretle
            izibiz.MarkInvoiceRequest markReq = new izibiz.MarkInvoiceRequest();
            izibiz.MarkInvoiceRequestMARK mark = new izibiz.MarkInvoiceRequestMARK();
            mark.INVOICE = invoiceList;
            mark.value = izibiz.MarkInvoiceRequestMARKValue.READ;
            mark.valueSpecified = true;
            markReq.MARK = mark;
            markReq.REQUEST_HEADER = requestHeader;
 
            izibiz.MarkInvoiceResponse markRes = service.MarkInvoice(markReq);

            System.Console.WriteLine("Mark Invoice Record Count :" + invoiceList.Length);
          
    }
 
        private void markInvoiceList(izibiz.INVOICE[] invoiceList)
    {
        System.Console.WriteLine("/****** MARKINVOICELIST() *******/");
            
            //faturaları okundu olarak işaretle
            izibiz.MarkInvoiceRequest markReq = new izibiz.MarkInvoiceRequest();
            izibiz.MarkInvoiceRequestMARK mark = new izibiz.MarkInvoiceRequestMARK();
            mark.INVOICE = invoiceList;
            mark.value = izibiz.MarkInvoiceRequestMARKValue.READ;
            mark.valueSpecified = true;
            markReq.MARK = mark;
            markReq.REQUEST_HEADER = requestHeader;
 
            izibiz.MarkInvoiceResponse markRes = service.MarkInvoice(markReq);

            System.Console.WriteLine("Mark Invoice Record Count :" + invoiceList.Length);
          
        }

        public void markInvoice(izibiz.INVOICE invoice)
        {
            System.Console.WriteLine("/****** MARKINVOICE() *******/");
            //faturaları okundu olarak işaretle
            izibiz.MarkInvoiceRequest markReq = new izibiz.MarkInvoiceRequest();
            izibiz.MarkInvoiceRequestMARK mark = new izibiz.MarkInvoiceRequestMARK();
            mark.INVOICE = new izibiz.INVOICE[1];
            mark.INVOICE[0] = invoice;
            mark.value = izibiz.MarkInvoiceRequestMARKValue.READ;
            mark.valueSpecified = true;
            markReq.MARK = mark;
            markReq.REQUEST_HEADER = requestHeader;

            izibiz.MarkInvoiceResponse markRes = service.MarkInvoice(markReq);


        }
        private void logInvoice(izibiz.INVOICE invoice)
        {
            System.Console.WriteLine(invoice.UUID.ToString() + "\t" + invoice.ID + "\t" +
                        invoice.HEADER.SENDER + "\t" + invoice.HEADER.RECEIVER);
            System.Console.WriteLine("-------------------------------------------------------------");
            System.Console.WriteLine(Encoding.UTF8.GetString(invoice.CONTENT.Value));
        }

        String inboxFolder = "D:\\temp\\INBOX\\";

        private void createInboxIfDoesNotExist(String inboxFolder)
        {
            if (!Directory.Exists(inboxFolder)) Directory.CreateDirectory(inboxFolder); 
        }
        private void saveInvoice(izibiz.INVOICE invoice) {

            createInboxIfDoesNotExist(inboxFolder);
            izibiz.INVOICEHEADER header = invoice.HEADER;
            string xmlContentStr = Encoding.UTF8.GetString(invoice.CONTENT.Value);
         
            //xml diske yazılıyor
            string filePath = Path.Combine(inboxFolder, invoice.ID + ".xml");
            using (StreamWriter outFile = new StreamWriter(filePath, false, System.Text.Encoding.UTF8))
            {
                outFile.Write(xmlContentStr);
                outFile.Close();
            }

        }

        private void saveInvoiceType(izibiz.INVOICE invoice)
        {

            createInboxIfDoesNotExist(inboxFolder);
            izibiz.INVOICEHEADER header = invoice.HEADER;
            string xmlContentStr = Encoding.UTF8.GetString(invoice.CONTENT.Value);

            //xml diske yazılıyor
            string filePath = Path.Combine(inboxFolder, invoice.ID + ".html");
            using (StreamWriter outFile = new StreamWriter(filePath, false, System.Text.Encoding.UTF8))
            {
                outFile.Write(xmlContentStr);
                outFile.Close();
            }

        }

        public void sendInvoice(String fromVkn, String fromAlias,
                                String toVkn, String toAlias){

      
            System.Console.WriteLine("/****** SENDINVOICE() *******/");

            //fatura oluşturma class
            CreateInvoice createInv = new CreateInvoice();
           string path = createInv.createInvoice();


            izibiz.SendInvoiceRequest sendInvoiceRequest = new izibiz.SendInvoiceRequest();
            sendInvoiceRequest.SENDER = new izibiz.SendInvoiceRequestSENDER();
            sendInvoiceRequest.SENDER.vkn = fromVkn;
            sendInvoiceRequest.SENDER.alias = fromAlias;
            sendInvoiceRequest.RECEIVER = new izibiz.SendInvoiceRequestRECEIVER();
            sendInvoiceRequest.RECEIVER.vkn = toVkn;
            sendInvoiceRequest.RECEIVER.alias = toAlias;
            sendInvoiceRequest.REQUEST_HEADER = requestHeader;

            List<izibiz.INVOICE> invoiceList = new List<izibiz.INVOICE>();
            izibiz.INVOICE invoice = new izibiz.INVOICE();
            izibiz.base64Binary content = new izibiz.base64Binary();

            String contentString = File.ReadAllText(path, Encoding.UTF8);
            byte[] contentByte = Encoding.UTF8.GetBytes(contentString);
            content.Value = contentByte;

            invoice.CONTENT = content;
            
            invoiceList.Add(invoice);

            sendInvoiceRequest.INVOICE = invoiceList.ToArray();

          service.SendInvoice(sendInvoiceRequest);

            System.Console.WriteLine("Invoice was sent");
        }

        public void sendInvoiceResponseAccept(String invoiceId) {

            System.Console.WriteLine("/****** SENDINVOICERESPONSE-ACCEPT() *******/");
            izibiz.SendInvoiceResponseWithServerSignRequest req = new izibiz.SendInvoiceResponseWithServerSignRequest();
            req.REQUEST_HEADER = requestHeader;
            req.STATUS = "KABUL";

            izibiz.INVOICE[] invoiceList = new izibiz.INVOICE[1];
            izibiz.INVOICE inv1 = new izibiz.INVOICE();
            inv1.ID = invoiceId;
            invoiceList[0] = inv1;
            req.INVOICE = invoiceList;

            service.SendInvoiceResponseWithServerSign(req);
        }
        public void sendInvoiceResponseReject(String invoiceId)
        {

            System.Console.WriteLine("/****** SENDINVOICERESPONSE-REJECT() *******/");
            izibiz.SendInvoiceResponseWithServerSignRequest req = new izibiz.SendInvoiceResponseWithServerSignRequest();
            req.REQUEST_HEADER = requestHeader;
            req.STATUS = "RED";

            izibiz.INVOICE[] invoiceList = new izibiz.INVOICE[1];
            izibiz.INVOICE inv1 = new izibiz.INVOICE();
            inv1.ID = invoiceId;
            invoiceList[0] = inv1;
            req.INVOICE = invoiceList;

            service.SendInvoiceResponseWithServerSign(req);
        }
        
        public void authRequestHead(string sessionId)
        {
            authrequestHeader = new auth.REQUEST_HEADERType();
            authrequestHeader.SESSION_ID = sessionId;
            authrequestHeader.CLIENT_TXN_ID = System.Guid.NewGuid().ToString();
            authrequestHeader.APPLICATION_NAME = "İZİBİZ EFATURA V1.0";
            authrequestHeader.CHANNEL_NAME = "İZİBİZ";
            authrequestHeader.HOSTNAME = "HOST-İZİBİZ-DEFAULT";
            authrequestHeader.REASON = "EFATURA GONDERME VE ALMA ISLEMLERI TEST";
            authrequestHeader.COMPRESSED = "N";
        }

        public void oibRequestHead(string sessionId)
        {
            requestHeader = new izibiz.REQUEST_HEADERType();
            requestHeader.SESSION_ID = sessionId;
            requestHeader.CLIENT_TXN_ID = System.Guid.NewGuid().ToString();
            requestHeader.APPLICATION_NAME = "İZİBİZ EFATURA V1.0";
            requestHeader.CHANNEL_NAME = "İZİBİZ";
            requestHeader.HOSTNAME = "HOST-İZİBİZ-DEFAULT";
            requestHeader.REASON = "EFATURA GONDERME VE ALMA ISLEMLERI TEST";
            requestHeader.COMPRESSED = "N";
        }



    }
}
