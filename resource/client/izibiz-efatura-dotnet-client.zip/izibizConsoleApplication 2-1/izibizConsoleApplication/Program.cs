﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Security;

namespace izibizConsoleApplication {

    class Program     {
        private static RemoteCertificateValidationCallback a;

        static void Main(string[] args) {
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls;
            a =  ServicePointManager.ServerCertificateValidationCallback = ((sender, certificate, chain, sslPolicyErrors) => true);

            EFatura eFatura = new EFatura();

          
            String username = "izibiz-test2";
            String password = "izi321";
            String senderVkn ="4840847211";
            String senderGB = "urn:mail:maslakgb@izibiz.com.tr";
            String receiverVkn = "4840847211";
            String receiverPK = "urn:mail:maslakpk@izibiz.com.tr";
            String invoiceFilePath = "D:\\temp\\TestInvoice.xml";
           
            //String invoiceFilePath = "D:\\temp\\TestInvoice.xml";

            // Kullanıcılar - sentinvoice ve getinvoice farklı kullanıcılar kullanılmalıdır
            eFatura.login(username, password);
            eFatura.getInvoice_ReceivedHeaderOnlyList("OUT", "Y");
            eFatura.getInvoice_ReceivedHeaderOnlyList("OUT", "N");
            eFatura.getInvoice_ReceivedHeaderOnlyList("IN", "Y");
            eFatura.getInvoice_ReceivedHeaderOnlyList("IN", "N");
            eFatura.markInvoiceManual();
            eFatura.sendInvoice(senderVkn, senderGB, receiverVkn, receiverPK);
            eFatura.getInvoicesReceived();
            eFatura.getInvoicesSent();
            eFatura.sendInvoiceResponseAccept("SPR2014000000003"); // Portalden daha once onaylanmamış bir fatura bulunmalı
            eFatura.sendInvoiceResponseReject("GEN2014900000018"); // Portalden daha once onaylanmamış bir fatura bulunmalı
            eFatura.logout();
            
            Console.ReadLine();
        }
    }
}
