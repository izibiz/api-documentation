﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace IzibizEarchiveConsoleProject
{
    class EArchive
    {
        private EArsivWS_Izibiz.EFaturaArchivePortClient ArchiveClient = new EArsivWS_Izibiz.EFaturaArchivePortClient();
        private EArsivWS_Izibiz.REQUEST_HEADERType RequestHeader;
        private EFaturaWS_Izibiz.EFaturaOIBPortClient service = new EFaturaWS_Izibiz.EFaturaOIBPortClient();
        private EFaturaWS_Izibiz.REQUEST_HEADERType requestHeader;

        public EArchive()
        {
            initialize();
        }

        private void initialize()
        {
            service = new EFaturaWS_Izibiz.EFaturaOIBPortClient();

            requestHeader = new EFaturaWS_Izibiz.REQUEST_HEADERType();
            requestHeader.SESSION_ID = "0";
            requestHeader.CLIENT_TXN_ID = System.Guid.NewGuid().ToString();
            requestHeader.APPLICATION_NAME = "İZİBİZ EFATURA V1.0";
            requestHeader.CHANNEL_NAME = "İZİBİZ";
            requestHeader.HOSTNAME = "HOST-İZİBİZ-DEFAULT";
            requestHeader.REASON = "EFATURA GONDERME VE ALMA ISLEMLERI TEST";
            requestHeader.COMPRESSED = "N";

            RequestHeader = new EArsivWS_Izibiz.REQUEST_HEADERType();
            RequestHeader.CLIENT_TXN_ID = System.Guid.NewGuid().ToString();
            RequestHeader.APPLICATION_NAME = "İZİBİZ E-ARŞİV FATURA YAZILIMI V1.0";
            RequestHeader.CHANNEL_NAME = "İZİBİZ";
            RequestHeader.HOSTNAME = "HOST-İZİBİZ-DEFAULT";
            RequestHeader.REASON = "E ARSIV FATURA GONDERME VE ALMA ISLEMLERI TEST";
            RequestHeader.COMPRESSED = "Y";

        }

        public void login(String userName, String password)
        {
            System.Console.WriteLine("/****** LOGIN() *******/");
            EFaturaWS_Izibiz.LoginRequest loginRequest = new EFaturaWS_Izibiz.LoginRequest();
            loginRequest.USER_NAME = userName;
            loginRequest.PASSWORD = password;
            loginRequest.REQUEST_HEADER = requestHeader;

            EFaturaWS_Izibiz.LoginResponse loginResponse = service.Login(loginRequest);
            String sessionId = loginResponse.SESSION_ID;
            requestHeader.SESSION_ID = sessionId;
            RequestHeader.SESSION_ID = sessionId;
        }


        public void logout()
        {
            System.Console.WriteLine("/****** LOGOUT() *******/");
            EFaturaWS_Izibiz.LogoutRequest logoutRequest = new EFaturaWS_Izibiz.LogoutRequest();
            logoutRequest.REQUEST_HEADER = requestHeader;

            EFaturaWS_Izibiz.LogoutResponse logoutResponse = service.Logout(logoutRequest);
        }

        public void getReadFromEArchive(String invoiceID, String direction, String profile, string invoiceZipSaveFilePath)
        {
            System.Console.WriteLine("/******READ FROM EARSIV() *******/");
            ArchiveClient = new EArsivWS_Izibiz.EFaturaArchivePortClient();
            EArsivWS_Izibiz.ArchiveInvoiceReadRequest archiveRead = new EArsivWS_Izibiz.ArchiveInvoiceReadRequest();
            archiveRead.REQUEST_HEADER = RequestHeader;
            archiveRead.INVOICEID = invoiceID;
            archiveRead.PORTAL_DIRECTION = direction;
            archiveRead.PROFILE = profile;
            EArsivWS_Izibiz.ArchiveInvoiceReadResponse resp = new EArsivWS_Izibiz.ArchiveInvoiceReadResponse();
            resp = ArchiveClient.ReadFromArchive(archiveRead);
            EArsivWS_Izibiz.base64Binary[] invoiceBase64 = resp.INVOICE;
            foreach (EArsivWS_Izibiz.base64Binary invoice in invoiceBase64)
            {
                string strModified = Convert.ToBase64String(invoice.Value);
                saveInvoice(strModified, invoiceZipSaveFilePath);
            }
        }




        public void getSendEarchive(String invoiceFilePath, string email)
        {
            System.Console.WriteLine("/****** SENDEARCHIVE() *******/");

            ArchiveClient = new EArsivWS_Izibiz.EFaturaArchivePortClient();
            EArsivWS_Izibiz.ArchiveInvoiceExtendedRequest sendArchieveInvoiceRequest = new EArsivWS_Izibiz.ArchiveInvoiceExtendedRequest();
            EArsivWS_Izibiz.ArchiveInvoiceExtendedContentINVOICE_PROPERTIES[] Arr_ContentProps = new EArsivWS_Izibiz.ArchiveInvoiceExtendedContentINVOICE_PROPERTIES[1];
            EArsivWS_Izibiz.ArchiveInvoiceExtendedContentINVOICE_PROPERTIES ContentProps = new EArsivWS_Izibiz.ArchiveInvoiceExtendedContentINVOICE_PROPERTIES();
            sendArchieveInvoiceRequest.REQUEST_HEADER = RequestHeader;
            ContentProps.EARSIV_FLAG = EArsivWS_Izibiz.FLAG_VALUE.Y;

            EArsivWS_Izibiz.EARSIV_PROPERTIES ContentDetails = new EArsivWS_Izibiz.EARSIV_PROPERTIES();
            ContentDetails.EARSIV_TYPE = EArsivWS_Izibiz.EARSIV_TYPE_VALUE.NORMAL;
            ContentDetails.SUB_STATUS = EArsivWS_Izibiz.SUB_STATUS_VALUE.NEW;
            ContentDetails.EARSIV_EMAIL_FLAG = EArsivWS_Izibiz.FLAG_VALUE.Y;
            if (ContentDetails.EARSIV_EMAIL_FLAG == EArsivWS_Izibiz.FLAG_VALUE.Y)
                ContentDetails.EARSIV_EMAIL = new string[] {email};

            ContentProps.EARSIV_PROPERTIES = ContentDetails;

            

            EArsivWS_Izibiz.base64Binary content = new EArsivWS_Izibiz.base64Binary();
            byte[] zipFileBinaryDataArray = null;

            using (MemoryStream memoryStreamOutput = new MemoryStream())
            {
                using (Ionic.Zip.ZipFile zip = new Ionic.Zip.ZipFile())
                {
                    zip.AddFile(invoiceFilePath, string.Empty);
                    zip.Save(memoryStreamOutput);
                }
                zipFileBinaryDataArray = memoryStreamOutput.ToArray();
            }
            content.Value = zipFileBinaryDataArray;
            ContentProps.INVOICE_CONTENT = content;
            Arr_ContentProps[0] = ContentProps;
            ContentProps.INVOICE_CONTENT.Value = content.Value;
            sendArchieveInvoiceRequest.ArchiveInvoiceExtendedContent = Arr_ContentProps;
            EArsivWS_Izibiz.ArchiveInvoiceExtendedResponse sendInvoiceResponse = ArchiveClient.WriteToArchiveExtended(sendArchieveInvoiceRequest);
            if (sendInvoiceResponse.ERROR_TYPE!= null)
            {
                Console.WriteLine(sendInvoiceResponse.ERROR_TYPE.ERROR_SHORT_DES);
            }
            else
            {
                Console.WriteLine("Yükleme Başarılı");
            }

        }

        public void cancelEarchive(string uuid)
        {
            Console.WriteLine("*************CANCEL EARCHIVE***********");
            //EArsivWS_Izibiz.CancelEArchiveInvoiceRequest[0] cancelEarchiveArrReq = new EArsivWS_Izibiz.CancelEArchiveInvoiceRequest[1]();
            EArsivWS_Izibiz.CancelEArchiveInvoiceRequest cancelEarchiveReq = new EArsivWS_Izibiz.CancelEArchiveInvoiceRequest();
            EArsivWS_Izibiz.CancelEArchiveInvoiceRequestCancelEArsivInvoiceContent[] contentArr = new EArsivWS_Izibiz.CancelEArchiveInvoiceRequestCancelEArsivInvoiceContent[1];
            EArsivWS_Izibiz.CancelEArchiveInvoiceRequestCancelEArsivInvoiceContent content = new EArsivWS_Izibiz.CancelEArchiveInvoiceRequestCancelEArsivInvoiceContent();
            cancelEarchiveReq.REQUEST_HEADER = RequestHeader;
            content.FATURANO = uuid;
            content.IPTAL_TARIHI = new DateTime();
            decimal d = decimal.Parse("12.47");
            content.TOPLAM_TUTAR = d;

            Boolean status = eArchiveStatus(uuid);
            if (status)
            {
                content.IPTAL_EAINVOICE_FLAG = EArsivWS_Izibiz.FLAG_VALUE.Y;
            }
            else
            {
                content.IPTAL_EAINVOICE_FLAG = EArsivWS_Izibiz.FLAG_VALUE.N;
            }
             contentArr[0] = content;
            cancelEarchiveReq.CancelEArsivInvoiceContent = contentArr;
            EArsivWS_Izibiz.CancelEArchiveInvoiceResponse resp = ArchiveClient.CancelEArchiveInvoice(cancelEarchiveReq);
            if (resp.ERROR_TYPE != null)
            {
                Console.WriteLine(resp.ERROR_TYPE.ERROR_SHORT_DES);
            }
            else
            {
                Console.WriteLine("Yükleme Başarılı");
            }

        }

        public Boolean eArchiveStatus(string uuid)
        {
            string[] invoiceUUID = new string[] { uuid };
            
            EArsivWS_Izibiz.GetEArchiveInvoiceStatusRequest eArchiveStatus = new EArsivWS_Izibiz.GetEArchiveInvoiceStatusRequest();
            eArchiveStatus.REQUEST_HEADER = RequestHeader;
            eArchiveStatus.UUID = invoiceUUID;
            EArsivWS_Izibiz.GetEArchiveInvoiceStatusResponse resp = ArchiveClient.GetEArchiveInvoiceStatus(eArchiveStatus);
            if (resp.INVOICE[0].HEADER.REPORT_ID != 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        [Flags]
        public enum Married
        {
            Y,
            N
        }

        private void saveInvoice(string invoice, String inboxFolder)
        {
            if (!Directory.Exists(inboxFolder)) Directory.CreateDirectory(inboxFolder);//klasör yoksa oluşturuyor

            UnzipToString(invoice, inboxFolder);


        }

        public void UnzipToString(string stringBase64Zipped, String inboxFolder)
        {
            var bytesZipFile = Convert.FromBase64String(stringBase64Zipped);
            var guid = Guid.NewGuid();
            var msZipFile = new MemoryStream(bytesZipFile);
            msZipFile.Position = 0;
            using (var zipFile1 = Ionic.Zip.ZipFile.Read(msZipFile))
            {
                zipFile1.Save(string.Format(inboxFolder + "{0}.zip", guid));  // This works
                var zipEntry1 = zipFile1.Entries.First();

                using (var ms = new MemoryStream())
                {
                    ms.Position = 0;
                    zipEntry1.Extract(ms);
                    var streamReader1 = new StreamReader(ms);
                    var result = String.Empty;
                    ms.Position = 0;
                    result = streamReader1.ReadToEnd();
                    Console.WriteLine("Arşiv Faturası KAyıt Edilmiştir. Klasör:" + inboxFolder + guid + ".zip");
                }
            }
        }

    }
}

