﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;


namespace IzibizEarchiveConsoleProject
{

    class Program
    {

        static void Main(string[] args)
        {

            ServicePointManager.ServerCertificateValidationCallback = ((sender, certificate, chain, sslPolicyErrors) => true);

            EArchive eArchive = new EArchive();

            String username = "izibiz-test2";
            String password = "izi321";

            string email = "yasar.gunes@izibiz.com.tr";//gönderilen e-arşiv faturasının hangi mail adresine yönlendirileceği.
            string invoiceZipFilePath = "D:\\temp\\EARCHIVE\\SEND\\YSR2015900000012.xml";//Gönderilecek e-arşiv faturasının yolu.
            string invoiceZipSaveFilePath = "D:\\temp\\EARCHIVE\\INBOX\\";//Read yapıldığında gelen invoicenin kayıt edileceği klasör
            string direction = "OUT";//Bu sabit bir değerdir.
           // string profile = "EA_CUST_PDF_SIGNED";// İmzalı PDF indirir
            string profile = "EA_CUST_XML_SIGNED";//İmzalı XML indirir
            string uuid = "8D4CC994-8370-43AD-BA19-5C7A34940D18";//Earşiv faturasının ETTN nosu
            eArchive.login(username, password);
            eArchive.cancelEarchive(uuid);
            eArchive.getSendEarchive(invoiceZipFilePath, email);
            eArchive.getReadFromEArchive(uuid, direction, profile, invoiceZipSaveFilePath);
            eArchive.logout();
            Console.ReadLine();
        }
    }
}
