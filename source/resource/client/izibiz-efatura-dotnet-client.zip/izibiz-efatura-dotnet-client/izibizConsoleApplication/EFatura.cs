﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace izibizConsoleApplication {

    class EFatura {
      

        private izibiz.EFaturaOIBPortClient service;
        private izibiz.REQUEST_HEADERType requestHeader;

        public EFatura() {
            initialize();
        }

        private void initialize() {
            service = new izibiz.EFaturaOIBPortClient();
            requestHeader = new izibiz.REQUEST_HEADERType();
            requestHeader.SESSION_ID = "0";
            requestHeader.CLIENT_TXN_ID = System.Guid.NewGuid().ToString();
            requestHeader.APPLICATION_NAME = "İZİBİZ EFATURA V1.0";
            requestHeader.CHANNEL_NAME = "İZİBİZ";
            requestHeader.HOSTNAME = "HOST-İZİBİZ-DEFAULT";
            requestHeader.REASON = "EFATURA GONDERME VE ALMA ISLEMLERI TEST";
            requestHeader.COMPRESSED = "N";
        }

        public void login(String userName, String password) {
            System.Console.WriteLine("/****** LOGIN() *******/");
            izibiz.LoginRequest loginRequest = new izibiz.LoginRequest();
            loginRequest.USER_NAME = userName;
            loginRequest.PASSWORD = password;
            loginRequest.REQUEST_HEADER = requestHeader;

            izibiz.LoginResponse loginResponse = service.Login(loginRequest);
            String sessionId = loginResponse.SESSION_ID;
            requestHeader.SESSION_ID = sessionId;
        }

        public void logout() {
            System.Console.WriteLine("/****** LOGOUT() *******/");
            izibiz.LogoutRequest logoutRequest = new izibiz.LogoutRequest();
            logoutRequest.REQUEST_HEADER = requestHeader;
            
            izibiz.LogoutResponse logoutResponse = service.Logout(logoutRequest);
        }


        public void getInvoice_SentHeaderOnlyList()
        {
            System.Console.WriteLine("/****** GETINVOICELIST_SENT_HEADERONLY() *******/");
            izibiz.GetInvoiceRequest getInvoiceRequest = new izibiz.GetInvoiceRequest();
            izibiz.GetInvoiceRequestINVOICE_SEARCH_KEY invoiceSearchKey = new izibiz.GetInvoiceRequestINVOICE_SEARCH_KEY();
            invoiceSearchKey.LIMIT = 100;
            invoiceSearchKey.LIMITSpecified = true;
            invoiceSearchKey.READ_INCLUDED = true;
            invoiceSearchKey.READ_INCLUDEDSpecified = true;
            invoiceSearchKey.DIRECTION = "OUT";
            getInvoiceRequest.HEADER_ONLY = "Y";
            getInvoiceRequest.INVOICE_SEARCH_KEY = invoiceSearchKey;
            getInvoiceRequest.REQUEST_HEADER = requestHeader;

            izibiz.INVOICE[] invoiceList = service.GetInvoice(getInvoiceRequest);
            foreach (izibiz.INVOICE invoice in invoiceList)
            {
                System.Console.WriteLine(invoice.UUID.ToString() + "\t" + invoice.ID + "\t" +
                    invoice.HEADER.FROM + "\t" + invoice.HEADER.TO + "\t" +
                    invoice.HEADER.SUPPLIER + "\t" + invoice.HEADER.CUSTOMER + "\t" +
                    invoice.HEADER.SENDER + "\t" + invoice.HEADER.RECEIVER);
            }
            System.Console.WriteLine("Total Record Count :" + invoiceList.Length);
        }

        public void getInvoice_ReceivedHeaderOnlyList()
        {
            System.Console.WriteLine("/****** GETINVOICELIST_RECEIVED_HEADERONLY() *******/");
            izibiz.GetInvoiceRequest getInvoiceRequest = new izibiz.GetInvoiceRequest();
            izibiz.GetInvoiceRequestINVOICE_SEARCH_KEY invoiceSearchKey = new izibiz.GetInvoiceRequestINVOICE_SEARCH_KEY();
            invoiceSearchKey.LIMIT = 100;
            invoiceSearchKey.LIMITSpecified = true;
            invoiceSearchKey.READ_INCLUDED = true;
            invoiceSearchKey.READ_INCLUDEDSpecified = true;
            invoiceSearchKey.DIRECTION = "IN";
            getInvoiceRequest.HEADER_ONLY = "Y";
            getInvoiceRequest.INVOICE_SEARCH_KEY = invoiceSearchKey;
            getInvoiceRequest.REQUEST_HEADER = requestHeader;

            izibiz.INVOICE[] invoiceList = service.GetInvoice(getInvoiceRequest);
            foreach (izibiz.INVOICE invoice in invoiceList)
            {
                System.Console.WriteLine(invoice.UUID.ToString() + "\t" + invoice.ID + "\t" +
                    invoice.HEADER.FROM + "\t" + invoice.HEADER.TO + "\t" +
                    invoice.HEADER.SUPPLIER + "\t" + invoice.HEADER.CUSTOMER + "\t" +
                    invoice.HEADER.SENDER + "\t" + invoice.HEADER.RECEIVER);
            }
            System.Console.WriteLine("Total Record Count :" + invoiceList.Length);
        }

        public void getInvoicesSent()
        {
            System.Console.WriteLine("/****** GETINVOICESSENT() *******/");
            izibiz.GetInvoiceRequest getInvoiceRequest = new izibiz.GetInvoiceRequest();
            izibiz.GetInvoiceRequestINVOICE_SEARCH_KEY invoiceSearchKey = new izibiz.GetInvoiceRequestINVOICE_SEARCH_KEY();
            invoiceSearchKey.LIMIT = 10;
            invoiceSearchKey.LIMITSpecified = true;
            invoiceSearchKey.READ_INCLUDED = true;
            invoiceSearchKey.READ_INCLUDEDSpecified = false;
            invoiceSearchKey.DIRECTION = "OUT";
            getInvoiceRequest.HEADER_ONLY = "N";
            getInvoiceRequest.INVOICE_SEARCH_KEY = invoiceSearchKey;
            getInvoiceRequest.REQUEST_HEADER = requestHeader;

            izibiz.INVOICE[] invoiceList = service.GetInvoice(getInvoiceRequest);
            foreach (izibiz.INVOICE invoice in invoiceList)
            {
                System.Console.WriteLine(invoice.UUID.ToString() + "\t" + invoice.ID + "\t" +
                    invoice.HEADER.SENDER + "\t" + invoice.HEADER.RECEIVER);
                System.Console.WriteLine("-------------------------------------------------------------");
                System.Console.WriteLine(Encoding.UTF8.GetString(invoice.CONTENT.Value));
            }
            System.Console.WriteLine("Total Record Count :" + invoiceList.Length);
        }

        public void getInvoicesReceived()
        {
            System.Console.WriteLine("/****** GETINVOICESRECEIVED() *******/");
            izibiz.GetInvoiceRequest getInvoiceRequest = new izibiz.GetInvoiceRequest();
            izibiz.GetInvoiceRequestINVOICE_SEARCH_KEY invoiceSearchKey = new izibiz.GetInvoiceRequestINVOICE_SEARCH_KEY();
            invoiceSearchKey.LIMIT = 100;
            invoiceSearchKey.LIMITSpecified = true;
            invoiceSearchKey.READ_INCLUDED = false;
            invoiceSearchKey.READ_INCLUDEDSpecified = true;
            invoiceSearchKey.DIRECTION = "IN";
            invoiceSearchKey.START_DATESpecified = true;
            invoiceSearchKey.START_DATE = new DateTime(2010, 09, 07);
            invoiceSearchKey.END_DATESpecified = true;
            invoiceSearchKey.END_DATE = new DateTime(2015, 09, 30);
            getInvoiceRequest.HEADER_ONLY = "N";
            getInvoiceRequest.INVOICE_SEARCH_KEY = invoiceSearchKey;
            getInvoiceRequest.REQUEST_HEADER = requestHeader;

            izibiz.INVOICE[] invoiceList = service.GetInvoice(getInvoiceRequest);
            foreach (izibiz.INVOICE invoice in invoiceList)
            {
                //logInvoice(invoice);
                saveInvoice(invoice);
                // Mark Invoice One by One
                markInvoice(invoice);
            }
           
            System.Console.WriteLine("Total Record Count :" + invoiceList.Length);

            // Mark Invoice One by One
            // if (invoiceList.Length > 0)
            //{
            //    markInvoiceList(invoiceList);
            //}

        }

        public void markInvoiceManual() {
            // REF: GetInvoice methoduna bakarak markinvoice ve getinvoice nasıl kullanıldıgınıda gorebilirsiniz.
            // Bu methodu kullanmadan once portalden daha once okunmamış fatura bilgilerini almanız gerekir.
            System.Console.WriteLine("/****** MARKINVOICEMANUAL() *******/");

            izibiz.INVOICE[] invoiceList = new izibiz.INVOICE[2];

            izibiz.INVOICE inv1 = new izibiz.INVOICE();
            inv1.ID = "SPR2014000000003";
            inv1.UUID = "E95DB6B9-0F4E-47ED-B96A-37F76B6F5E18";
            invoiceList[0] = inv1;

            izibiz.INVOICE inv2 = new izibiz.INVOICE();
            inv2.ID = "ABC2014000000115";
            inv2.UUID = "CD51075F-C214-450F-AFD6-9A542E33D6AC";
            invoiceList[1] = inv2;

            //faturaları okundu olarak işaretle
            izibiz.MarkInvoiceRequest markReq = new izibiz.MarkInvoiceRequest();
            izibiz.MarkInvoiceRequestMARK mark = new izibiz.MarkInvoiceRequestMARK();
            mark.INVOICE = invoiceList;
            mark.value = izibiz.MarkInvoiceRequestMARKValue.READ;
            mark.valueSpecified = true;
            markReq.MARK = mark;
            markReq.REQUEST_HEADER = requestHeader;
 
            izibiz.MarkInvoiceResponse markRes = service.MarkInvoice(markReq);

            System.Console.WriteLine("Mark Invoice Record Count :" + invoiceList.Length);
          
    }
 
        private void markInvoiceList(izibiz.INVOICE[] invoiceList)
    {
        System.Console.WriteLine("/****** MARKINVOICELIST() *******/");
            
            //faturaları okundu olarak işaretle
            izibiz.MarkInvoiceRequest markReq = new izibiz.MarkInvoiceRequest();
            izibiz.MarkInvoiceRequestMARK mark = new izibiz.MarkInvoiceRequestMARK();
            mark.INVOICE = invoiceList;
            mark.value = izibiz.MarkInvoiceRequestMARKValue.READ;
            mark.valueSpecified = true;
            markReq.MARK = mark;
            markReq.REQUEST_HEADER = requestHeader;
 
            izibiz.MarkInvoiceResponse markRes = service.MarkInvoice(markReq);

            System.Console.WriteLine("Mark Invoice Record Count :" + invoiceList.Length);
          
        }

        public void markInvoice(izibiz.INVOICE invoice)
        {
            System.Console.WriteLine("/****** MARKINVOICE() *******/");
            //faturaları okundu olarak işaretle
            izibiz.MarkInvoiceRequest markReq = new izibiz.MarkInvoiceRequest();
            izibiz.MarkInvoiceRequestMARK mark = new izibiz.MarkInvoiceRequestMARK();
            mark.INVOICE = new izibiz.INVOICE[1];
            mark.INVOICE[0] = invoice;
            mark.value = izibiz.MarkInvoiceRequestMARKValue.READ;
            mark.valueSpecified = true;
            markReq.MARK = mark;
            markReq.REQUEST_HEADER = requestHeader;

            izibiz.MarkInvoiceResponse markRes = service.MarkInvoice(markReq);


        }
        private void logInvoice(izibiz.INVOICE invoice)
        {
            System.Console.WriteLine(invoice.UUID.ToString() + "\t" + invoice.ID + "\t" +
                        invoice.HEADER.SENDER + "\t" + invoice.HEADER.RECEIVER);
            System.Console.WriteLine("-------------------------------------------------------------");
            System.Console.WriteLine(Encoding.UTF8.GetString(invoice.CONTENT.Value));
        }

        String inboxFolder = "D:\\temp\\INBOX\\";

        private void createInboxIfDoesNotExist(String inboxFolder)
        {
            if (!Directory.Exists(inboxFolder)) Directory.CreateDirectory(inboxFolder); 
        }
        private void saveInvoice(izibiz.INVOICE invoice) {

            createInboxIfDoesNotExist(inboxFolder);
            izibiz.INVOICEHEADER header = invoice.HEADER;
            string xmlContentStr = Encoding.UTF8.GetString(invoice.CONTENT.Value);
         
            //xml diske yazılıyor
            string filePath = Path.Combine(inboxFolder, invoice.ID + ".xml");
            using (StreamWriter outFile = new StreamWriter(filePath, false, System.Text.Encoding.UTF8))
            {
                outFile.Write(xmlContentStr);
                outFile.Close();
            }

        }
      
        public void sendInvoice(String fromVkn, String fromAlias,
                                String toVkn, String toAlias,
                                String fileName){

      
            System.Console.WriteLine("/****** SENDINVOICE() *******/");
            izibiz.SendInvoiceRequest sendInvoiceRequest = new izibiz.SendInvoiceRequest();
            sendInvoiceRequest.SENDER = new izibiz.SendInvoiceRequestSENDER();
            sendInvoiceRequest.SENDER.vkn = fromVkn;
            sendInvoiceRequest.SENDER.alias = fromAlias;
            sendInvoiceRequest.RECEIVER = new izibiz.SendInvoiceRequestRECEIVER();
            sendInvoiceRequest.RECEIVER.vkn = toVkn;
            sendInvoiceRequest.RECEIVER.alias = toAlias;
            sendInvoiceRequest.REQUEST_HEADER = requestHeader;

            List<izibiz.INVOICE> invoiceList = new List<izibiz.INVOICE>();
            izibiz.INVOICE invoice = new izibiz.INVOICE();
            izibiz.base64Binary content = new izibiz.base64Binary();

            String contentString = File.ReadAllText(fileName, Encoding.UTF8);
            byte[] contentByte = Encoding.UTF8.GetBytes(contentString);
            content.Value = contentByte;

            invoice.CONTENT = content;
            
            invoiceList.Add(invoice);

            sendInvoiceRequest.INVOICE = invoiceList.ToArray();

          service.SendInvoice(sendInvoiceRequest);

            System.Console.WriteLine("Invoice was sent");
        }

        public void sendInvoiceResponseAccept(String invoiceId) {

            System.Console.WriteLine("/****** SENDINVOICERESPONSE-ACCEPT() *******/");
            izibiz.SendInvoiceResponseWithServerSignRequest req = new izibiz.SendInvoiceResponseWithServerSignRequest();
            req.REQUEST_HEADER = requestHeader;
            req.STATUS = "KABUL";

            izibiz.INVOICE[] invoiceList = new izibiz.INVOICE[1];
            izibiz.INVOICE inv1 = new izibiz.INVOICE();
            inv1.ID = invoiceId;
            invoiceList[0] = inv1;
            req.INVOICE = invoiceList;

            service.SendInvoiceResponseWithServerSign(req);
        }
        public void sendInvoiceResponseReject(String invoiceId)
        {

            System.Console.WriteLine("/****** SENDINVOICERESPONSE-REJECT() *******/");
            izibiz.SendInvoiceResponseWithServerSignRequest req = new izibiz.SendInvoiceResponseWithServerSignRequest();
            req.REQUEST_HEADER = requestHeader;
            req.STATUS = "RED";

            izibiz.INVOICE[] invoiceList = new izibiz.INVOICE[1];
            izibiz.INVOICE inv1 = new izibiz.INVOICE();
            inv1.ID = invoiceId;
            invoiceList[0] = inv1;
            req.INVOICE = invoiceList;

            service.SendInvoiceResponseWithServerSign(req);
        }

        public void checkUserByIdentifier(String identifier) {
            System.Console.WriteLine("/****** CHECKUSERBYIDENTIFIER() *******/");
            izibiz.CheckUserRequest checkUserRequest = new izibiz.CheckUserRequest();
            checkUserRequest.USER = new izibiz.GIBUSER();
            checkUserRequest.USER.IDENTIFIER = identifier;
            checkUserRequest.REQUEST_HEADER = requestHeader;

            izibiz.GIBUSER[] userDetails = service.CheckUser(checkUserRequest);
            foreach (izibiz.GIBUSER user in userDetails) {
                System.Console.WriteLine(user.IDENTIFIER + "\t" + user.ALIAS + "\t" + user.IDENTIFIER + "\t" + user.TITLE);
            }
        }
        public void checkUserByTitle(String title) {
            System.Console.WriteLine("/****** CHECKUSERBYTITLE() *******/");
            izibiz.CheckUserRequest checkUserRequest = new izibiz.CheckUserRequest();
            checkUserRequest.USER = new izibiz.GIBUSER();
            checkUserRequest.USER.TITLE = title;
            checkUserRequest.REQUEST_HEADER = requestHeader;

            izibiz.GIBUSER[] userDetails = service.CheckUser(checkUserRequest);
            foreach (izibiz.GIBUSER user in userDetails) {
                System.Console.WriteLine(user.IDENTIFIER + "\t" + user.ALIAS + "\t" + user.IDENTIFIER + "\t" + user.TITLE);
            }
        }

        public void getUserList() {
            System.Console.WriteLine("/****** GETUSERLIST() *******/");
            izibiz.GetUserListRequest getUserListRequest = new izibiz.GetUserListRequest();
            getUserListRequest.REQUEST_HEADER = requestHeader;

            izibiz.GetUserListResponse getUserListResponse = service.GetUserList(getUserListRequest);

            izibiz.GIBUSER[] userList = getUserListResponse.Items;
            foreach (izibiz.GIBUSER user in userList) {
                System.Console.WriteLine(user.IDENTIFIER + "\t"+ user.ALIAS + "\t" + user.IDENTIFIER + "\t" + user.TITLE );
            }
        }      

    }
}
