﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;


namespace izibizConsoleApplication {

    class Program     {
        
        static void Main(string[] args) {

            ServicePointManager.ServerCertificateValidationCallback = ((sender, certificate, chain, sslPolicyErrors) => true);

            EFatura eFatura = new EFatura();

            String username = "izibiz-test2";
            String password = "izi321";

            String senderVkn ="4840847211";
            String senderGB = "urn:mail:maslakgb@izibiz.com.tr";
            String receiverVkn = "4840847211";
            String receiverPK = "urn:mail:maslakpk@izibiz.com.tr";
            String invoiceFilePath = "D:\\temp\\TestInvoice.xml";

            // Kullanıcılar - sentinvoice ve getinvoice farklı kullanıcılar kullanılmalıdır
            eFatura.login(username, password);
          //  eFatura.sendInvoice(senderVkn, senderGB, receiverVkn, receiverPK, invoiceFilePath);
            eFatura.getInvoicesReceived();
            //eFatura.getInvoicesSent();
            //eFatura.getInmarkInvoiceManualvoice_SentHeaderOnlyList();
            //eFatura.getInvoice_ReceivedHeaderOnlyList();
            //eFatura.markInvoiceManual();
            //eFatura.sendInvoiceResponseAccept("SPR2014000000003"); // Portalden daha once onaylanmamış bir fatura bulunmalı
            //eFatura.sendInvoiceResponseReject("GEN2014900000018"); // Portalden daha once onaylanmamış bir fatura bulunmalı

            // GIB User actions
            //eFatura.checkUserByIdentifier("1234567804");
            //eFatura.checkUserByTitle("Test");
            //eFatura.getUserList();
            
            eFatura.logout();
            
            Console.ReadLine();
        }
    }
}
